--  PROGRAM NAME:  accuplacer_insert_sortest.sql
--  VERSION:       1.0
--  DATE:          March 28, 2017 Emily Smartt
--  DESCRIPTION:   This script will load the accuplacer test scores from the
--                 temp table, pscccustom.accuplacer_temp into SORTEST.
--                 Insert new  records only where no accuplacer record exists for student.
--
--                 This script loads ACCUPLACER scores for
--                                  [Sentence Skills] (C21), 
--                                  [Reading Comprehension] (C20),
--                                  [Elementary Algebra] (C23).  
--
--  11/2018 CHANGE FOR ACCUPLACER NEXT GENERATION TESTS
--                     BANNER       ACCUPLACER TEST
--						C31 	Next-Generation Reading
--						C32 	Next-Generation Writing
--						C34		Next-Generation Quantitative Reasoning- Algebra- and Statistics
--
-- 
--              
--
spool &1;
set echo off;
set verify off;
set feedback off;
set heading on;
set pagesize 55;
set linesize 132;
set timing off;
set tab off;
set newpage 0;
set serveroutput on SIZE 1000000;

--
--  Declare variables
--
--

DECLARE
     v_stucount                  NUMBER (6) := 0;
     v_errcount                  NUMBER (6) := 0;
     v_warcount                  NUMBER (6) := 0;
     v_line_number               NUMBER (6) := 0;
     v_reading_inscount          NUMBER (6) := 0;
     v_writing_inscount          NUMBER (6) := 0;
     v_math_inscount             NUMBER (6) := 0;
     v_total_records_inscount    NUMBER (6) := 0;
     v_readingscore              NUMBER (6);
     v_writingscore              NUMBER (6);
     v_mathscore                 NUMBER (6);
     --
     v_reading_exists_count      NUMBER (6) := 0;
     v_writing_exists_count      NUMBER (6) := 0;
     v_math_exists_count         NUMBER (6) := 0;
     --
     v_disp_date                 VARCHAR (25) := TO_CHAR (SYSDATE, 'DD-MON-YYYY HH:MI:SS AM');
     v_pidm                      NUMBER (8);
     V_id                        VARCHAR2 (10);
     vid_exist                   VARCHAR2 (1);
     vname_exist                 VARCHAR2 (1);

     v_test_date                 DATE;
     v_report_line               VARCHAR2 (125);

-- 11/2018 - classic accuplacer tests replaced by next generation tests
--   v_READINGCODE               CHAR(3) := 'C20';
--   v_WRITINGCODE               CHAR(3) := 'C21';
--   v_MATHCODE                  CHAR(3) := 'C23';+

--
--  NEXTGEN CODES (EFF 11/01/2018)
      v_READINGCODE               CHAR(3) := 'C31';
      v_WRITINGCODE               CHAR(3) := 'C32';
      v_MATHCODE                  CHAR(3) := 'C34';
   
     --
     CURSOR temptab_accuplacer_cur
     IS
          SELECT FIRSTNAME, LASTNAME, STUDENT_ID, TESTDATE,
                 TESTNAME1, SCORE1, CSEM1, TESTNAME2,
                 SCORE2, CSEM2, TESTNAME3, SCORE3,
                 CSEM3
            FROM BANINST1.CLSCC_ACCUPLACER_TEMP
           WHERE (SCORE1 IS NOT NULL
                  OR SCORE2 IS NOT NULL
                  OR SCORE3 IS NOT NULL);

     temptab_accuplacer_rec      temptab_accuplacer_cur%ROWTYPE;

     CURSOR check_spriden_id
     IS
          SELECT 'X'
            FROM spriden
           WHERE spriden_id = V_id AND spriden_change_ind IS NULL;

     CURSOR check_spriden_name
     IS
          SELECT 'X'
            FROM spriden
           WHERE spriden_id = V_id
                 AND UPPER (SUBSTR (spriden_last_name, 1, 15)) =
                          UPPER (temptab_accuplacer_rec.LASTNAME)
                 AND spriden_change_ind IS NULL;


     CURSOR check_sortest_writing
     IS
          SELECT sortest_test_score, sortest_test_date
            FROM sortest
           WHERE sortest_pidm = v_pidm
                 AND sortest_tesc_code = v_WRITINGCODE
                 AND TO_CHAR (sortest_test_date, 'rrrrmmdd') =
                          TO_CHAR (v_test_date, 'rrrrmmdd');

     check_sortest_writing_rec   check_sortest_writing%ROWTYPE;

     CURSOR check_sortest_math
     IS
          SELECT sortest_test_score, sortest_test_date
            FROM sortest
           WHERE sortest_pidm = v_pidm
                 AND sortest_tesc_code = v_MATHCODE
                 AND TO_CHAR (sortest_test_date, 'rrrrmmdd') =
                          TO_CHAR (v_test_date, 'rrrrmmdd');

     check_sortest_math_rec      check_sortest_math%ROWTYPE;

     CURSOR check_sortest_reading
     IS
          SELECT sortest_test_score, sortest_test_date
            FROM sortest
           WHERE sortest_pidm = v_pidm
                 AND sortest_tesc_code = v_READINGCODE
                 AND TO_CHAR (sortest_test_date, 'rrrrmmdd') =
                          TO_CHAR (v_test_date, 'rrrrmmdd');

     check_sortest_reading_rec   check_sortest_reading%ROWTYPE;
--  Begin processing

BEGIN
	  DBMS_OUTPUT.ENABLE (1000000);
	  DBMS_OUTPUT.PUT_LINE (
			  CHR (9)
		   || '     accuplacer READING, WRITNG, MATH SCORES DATA LOAD REPORT - '
		   || v_disp_date);
	  DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
	  DBMS_OUTPUT.PUT_LINE (
		   '------------------------------------------------------------------------------');
	  DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');

     SELECT NVL (MAX (report_line_number), 0)
       INTO v_line_number
       FROM BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT a
      WHERE TO_CHAR (report_date, 'rrrrmmdd') = TO_CHAR (SYSDATE, 'rrrrmmdd')
            AND report_test_type IN (v_READINGCODE, v_WRITINGCODE, v_MATHCODE);

     --
     OPEN temptab_accuplacer_cur;

     LOOP
          FETCH temptab_accuplacer_cur INTO temptab_accuplacer_rec;

          --
          IF temptab_accuplacer_cur%FOUND
          THEN
          
               v_stucount := v_stucount + 1;
               
               V_id := temptab_accuplacer_rec.STUDENT_ID;
   --           if substr(V_id,1,1) <> 'P' THEN
   --             V_id := 'P' || V_id;
   --             end if;
                               
               v_test_date := to_date(temptab_accuplacer_rec.TESTDATE,'yyyy-mm-dd');



               OPEN check_spriden_id;



               FETCH check_spriden_id INTO vid_exist;

               --
               IF check_spriden_id%FOUND
               THEN
                    --
                    OPEN check_spriden_name;

                    FETCH check_spriden_name INTO vname_exist;

                    --
                    IF check_spriden_name%FOUND
                    THEN
                         SELECT spriden_pidm
                           INTO v_pidm
                           FROM spriden
                          WHERE spriden_id = V_id
                                AND UPPER (SUBSTR (spriden_last_name, 1, 15)) =
                                         UPPER (
                                              temptab_accuplacer_rec.LASTNAME)
                                AND spriden_change_ind IS NULL;

                         --

                         --               v_scount := v_scount + 1;
                         --
                         --
                         v_readingscore := NULL;
                         v_writingscore := NULL;
                         v_mathscore := NULL;
                         
                         IF UPPER (temptab_accuplacer_rec.TESTNAME1) =
                                 UPPER ('Next-Generation Reading')
                         THEN
                              v_readingscore := LPAD(temptab_accuplacer_rec.Score1,3,0);
                         ELSIF UPPER (temptab_accuplacer_rec.TESTNAME2) =
                                    UPPER ('Next-Generation Reading')
                         THEN
                              v_readingscore := LPAD(temptab_accuplacer_rec.Score2,3,0);
                         ELSIF UPPER (temptab_accuplacer_rec.TESTNAME3) =
                                    UPPER ('Next-Generation Reading')
                         THEN
                              v_readingscore := LPAD(temptab_accuplacer_rec.Score3,3,0);
                         END IF;

                         IF UPPER (temptab_accuplacer_rec.TESTNAME1) =
                                 UPPER ('Next-Generation Writing')
                         THEN
                              v_writingscore := LPAD(temptab_accuplacer_rec.Score1,3,0);
                         ELSIF UPPER (temptab_accuplacer_rec.TESTNAME2) =
                                    UPPER ('Next-Generation Writing')
                         THEN
                              v_writingscore := LPAD(temptab_accuplacer_rec.Score2,3,0);
                         ELSIF UPPER (temptab_accuplacer_rec.TESTNAME3) =
                                    UPPER ('Next-Generation Writing')
                         THEN
                              v_writingscore := LPAD(temptab_accuplacer_rec.Score3,3,0);
                         END IF;


                         IF UPPER (temptab_accuplacer_rec.TESTNAME1) =
                                 UPPER ('Next-Generation Quantitative Reasoning- Algebra- and Statistics')
                         THEN
                              v_mathscore := LPAD(temptab_accuplacer_rec.Score1,3,0);
                         ELSIF UPPER (temptab_accuplacer_rec.TESTNAME2) =
                                    UPPER ('Next-Generation Quantitative Reasoning- Algebra- and Statistics')
                         THEN
                              v_mathscore := LPAD(temptab_accuplacer_rec.Score2,3,0);
                         ELSIF UPPER (temptab_accuplacer_rec.TESTNAME3) =
                                    UPPER ('Next-Generation Quantitative Reasoning- Algebra- and Statistics')
                         THEN
                              v_mathscore := LPAD(temptab_accuplacer_rec.Score3,3,0);
                         END IF;

                         --  BEGIN accuplacer Reading Score block

                         IF v_readingscore IS NOT NULL
                         THEN
                              OPEN check_sortest_reading;

                              FETCH check_sortest_reading INTO check_sortest_reading_rec;

                              IF check_sortest_reading%NOTFOUND
                              THEN

                                   INSERT INTO sortest
                                       (sortest_pidm, 
										sortest_tesc_code, 
										sortest_test_date, 
										sortest_test_score,
										sortest_activity_date,
										sortest_term_code_entry, 
										sortest_appl_no,                                   
										sortest_release_ind, 
										sortest_equiv_ind,                                   
										sortest_user_id, sortest_data_origin )
                                  
								VALUES
                                       (v_pidm, 
										v_READINGCODE, 
										v_test_date,
										LPAD(v_readingscore,3,0),	                                   
										sysdate,
                                        '999999', 
										NULL, 
										'N', 
										'N', 
										'BANWORX', 
										'LOAD_accuplacer_SORTEST_TABLE');

--    Insert output line into output table
--
--
                                   v_line_number := v_line_number + 1;
                                   v_report_line :=
                                           'INSERT - '
                                        || V_id
                                        || ' '
                                        || INITCAP (
                                                temptab_accuplacer_rec.LASTNAME)
                                        || ', '
                                        || INITCAP (
                                                temptab_accuplacer_rec.FIRSTNAME)
                                        || '  test date: '
                                        || TO_CHAR (v_test_date, 'DD-MON-RR')
                                        || '  READING score ('||v_READINGCODE||'): '
                                        || v_readingscore;
--
                                   DBMS_OUTPUT.PUT_LINE (v_report_line);

 --
                                   INSERT
                                     INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                               report_date,
                                               report_line_number,
                                               report_line,
                                               report_process,
                                               report_test_type)
											   --
									VALUES 	(SYSDATE,
											v_line_number,
											v_report_line,
											'INSERT',
											v_READINGCODE);

                                   v_reading_inscount := v_reading_inscount + 1;
--						  
                              ELSE
                                   v_line_number := v_line_number + 1;
                                   v_report_line :=
                                        'No INSERT - accuplacer READING record ('||v_READINGCODE||') exists in Banner for: '
                                        || V_id
                                        || '  test date: '
                                        || TO_CHAR (check_sortest_reading_rec.sortest_test_date, 'DD-MON-RR')
                                        || '  test score: '
                                        || check_sortest_reading_rec.sortest_test_score;
                                   --
                                   DBMS_OUTPUT.PUT_LINE (v_report_line);

                                   --
                                   INSERT
                                     INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                               report_date,
                                               report_line_number,
                                               report_line,
                                               report_process,
                                               report_test_type)
									VALUES (SYSDATE,
                                           v_line_number,
                                           v_report_line,
                                           'EXISTS',
                                           v_READINGCODE);

                                   v_reading_exists_count := v_reading_exists_count + 1;
                              --
                              --
                              END IF;

                              CLOSE check_sortest_reading;
                         END IF;

                         --
                         -- END accuplacer Reading Score block
                         --
                         --
                         --  BEGIN accuplacer Writing Score block

                         IF v_writingscore IS NOT NULL
                         THEN
                              OPEN check_sortest_writing;

                              FETCH check_sortest_writing
                                   INTO check_sortest_writing_rec;

                              IF check_sortest_writing%NOTFOUND
                              THEN

                                INSERT INTO sortest
                                   (sortest_pidm, 
								   sortest_tesc_code, 
								   sortest_test_date, 
								   sortest_test_score,
                                   sortest_activity_date,
								   sortest_term_code_entry, 
								   sortest_appl_no,
                                   sortest_release_ind, 
								   sortest_equiv_ind,
                                   sortest_user_id, 
								   sortest_data_origin )
								VALUES
                                   (v_pidm, 
								   v_WRITINGCODE, 
								   v_test_date,
                                   LPAD(v_writingscore,3,0),
                                   sysdate,
                                   '999999', 
								   NULL, 
								   'N', 
								   'N', 
								   'BANWORX', 
								   'LOAD_accuplacer_SORTEST_TABLE');

                                   --
                                   --
                                   v_line_number := v_line_number + 1;
                                   v_report_line :=
								      'INSERT - '
									  || V_id|| ' '
                                      || INITCAP (temptab_accuplacer_rec.LASTNAME)
                                      || ', '|| INITCAP (temptab_accuplacer_rec.FIRSTNAME)
                                      || '  test date: '|| TO_CHAR (v_test_date, 'DD-MON-RR')
                                      || '  WRITING score ('||v_WRITINGCODE||'): '|| v_writingscore;
                                   --
                                   DBMS_OUTPUT.PUT_LINE (v_report_line);

                                   INSERT
                                     INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                               report_date,
                                               report_line_number,
                                               report_line,
                                               report_process,
                                               report_test_type)
                                   VALUES (SYSDATE,
                                           v_line_number,
                                           v_report_line,
                                           'INSERT',
                                           v_WRITINGCODE);

                                   v_writing_inscount := v_writing_inscount + 1;
                              --



                              ELSE
                                   --
                                   --
                                   v_line_number := v_line_number + 1;
                                   v_report_line :=
                                        'No INSERT - accuplacer WRITING record ('||v_WRITINGCODE||') exists in Banner for: '
                                        || V_id
                                        || '  test date: '
                                        || TO_CHAR (check_sortest_writing_rec.sortest_test_date, 'DD-MON-RR')
                                        || '  test score: '
                                        || check_sortest_writing_rec.sortest_test_score;

                                   --
                                   DBMS_OUTPUT.PUT_LINE (v_report_line);

                                   INSERT
                                     INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                               report_date,
                                               report_line_number,
                                               report_line,
                                               report_process,
                                               report_test_type)
                                   VALUES (SYSDATE,
                                           v_line_number,
                                           v_report_line,
                                           'EXISTS',
                                           v_WRITINGCODE);

                                   v_writing_exists_count :=
                                        v_writing_exists_count + 1;
                              END IF;

                              CLOSE check_sortest_writing;
                         END IF;

                         --
                         -- END accuplacer Writing Score block
                         --
                         --
                         --  BEGIN accuplacer MATH Score block

                         IF v_mathscore IS NOT NULL
                         THEN
                              OPEN check_sortest_math;

                              FETCH check_sortest_math
                                   INTO check_sortest_math_rec;

                              IF check_sortest_math%NOTFOUND
                              THEN
 
                               INSERT 
								 INTO sortest
                                   (sortest_pidm, 
								   sortest_tesc_code, 
								   sortest_test_date, 
								   sortest_test_score,
                                   sortest_activity_date,
								   sortest_term_code_entry, 
								   sortest_appl_no,
                                   sortest_release_ind, 
								   sortest_equiv_ind,
                                   sortest_user_id, 
								   sortest_data_origin )
                                 VALUES
                                   (v_pidm, 
								   v_MATHCODE, 
								   v_test_date,
                                   LPAD(v_mathscore,3,0),
                                   sysdate,
                                   '999999', 
								   NULL, 
								   'N', 
								   'N', 
								   'BANWORX', 
								   'LOAD_accuplacer_SORTEST_TABLE');

                                   --
                                   --
                                   v_line_number := v_line_number + 1;
                                   v_report_line :=
                                        'INSERT - '
                                        || V_id
                                        || ' '
                                        || INITCAP (temptab_accuplacer_rec.LASTNAME)
                                        || ', '
                                        || INITCAP (temptab_accuplacer_rec.FIRSTNAME)
                                        || '  test date: '
                                        || TO_CHAR (v_test_date, 'DD-MON-RR')
                                        || '  MATH score    ('||v_MATHCODE||'): '
                                        || v_mathscore;
                                   --
                                   DBMS_OUTPUT.PUT_LINE (v_report_line);

                                   --

                                   INSERT
                                     INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                               report_date,
                                               report_line_number,
                                               report_line,
                                               report_process,
                                               report_test_type)
                                   VALUES (SYSDATE,
                                           v_line_number,
                                           v_report_line,
                                           'INSERT',
                                           v_MATHCODE);

                                   v_math_inscount := v_math_inscount + 1;
                              ELSE
                                   --
                                   --
                                   v_line_number := v_line_number + 1;
                                   v_report_line :=
                                       'No INSERT - accuplacer MATH record ('||v_MATHCODE||') exists in Banner for: '
                                        || V_id
                                        || '  test date: '
                                        || TO_CHAR (check_sortest_math_rec.sortest_test_date, 'DD-MON-RR')
                                        || '  test score: '
                                        || check_sortest_math_rec.sortest_test_score;

                                   DBMS_OUTPUT.PUT_LINE (v_report_line);

                                   --

                                   INSERT
                                     INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                               report_date,
                                               report_line_number,
                                               report_line,
                                               report_process,
                                               report_test_type)
                                   VALUES (SYSDATE,
                                           v_line_number,
                                           v_report_line,
                                           'EXISTS',
                                           v_MATHCODE);

                                   v_math_exists_count :=  v_math_exists_count + 1;
                              END IF;

                              CLOSE check_sortest_math;
                         END IF; --
                    -- END accuplacer MATH Score block
                    --
                    --
                    -- IF THE LAST NAME DOES NOT MATCH THE STUDENT_ID IN SPRIDEN
                    --



                    ELSE
                         --
                         --
                         v_line_number := v_line_number + 1;
                         v_report_line :=
                                 'WARNING - Student Last Name does NOT Match STUDENT_ID. '
                              || INITCAP (temptab_accuplacer_rec.LASTNAME)
                              || '-'
                              || V_id;
                         --
                         DBMS_OUTPUT.PUT_LINE (v_report_line);

                         --
                         INSERT
                           INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                     report_date,
                                     report_line_number,
                                     report_line,
                                     report_process,
                                     report_test_type)
                         VALUES (SYSDATE,
                                 v_line_number,
                                 v_report_line,
                                 'WARNING',
                                 'CRWM');

                         v_warcount := v_warcount + 1;
                    END IF;

                    CLOSE check_spriden_name;
               --
               -- IF THE STUDENT_ID DOES NOT EXIST IN SPRIDEN
               --
               ELSE
                    --
                    --
                    v_line_number := v_line_number + 1;
                    v_report_line :=
                            'ERROR - STUDENT_ID does NOT Exist for '
                         || INITCAP (temptab_accuplacer_rec.LASTNAME)
                         || ','
                         || INITCAP (temptab_accuplacer_rec.FIRSTNAME)
                         || ' loadfile STUDENT_ID='
                         || V_id;
                    --
                    DBMS_OUTPUT.PUT_LINE (v_report_line);

                    --
                    --
                    INSERT
                      INTO BANINST1.CLSCC_ACCUPLACER_LOAD_OUTPUT (
                                report_date,
                                report_line_number,
                                report_line,
                                report_process,
                                report_test_type)
                    VALUES (SYSDATE,
                            v_line_number,
                            v_report_line,
                            'ERROR',
                            'CRWM');

                    v_errcount := v_errcount + 1;
               END IF; --check_spriden_id%FOUND

               CLOSE check_spriden_id;
          --
          END IF; --temptab_accuplacer_cur%FOUND

          EXIT WHEN temptab_accuplacer_cur%NOTFOUND;
          --
          DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     END LOOP;

     --
     v_total_records_inscount :=
          v_reading_inscount + v_writing_inscount + v_math_inscount;

     --
     --
     --
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student accuplacer Reading records Inserted ('||v_READINGCODE||') = '
          || v_reading_inscount);
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student records Not Inserted because accuplacer Reading soatest record exists ('||v_READINGCODE||') = '
          || v_reading_exists_count);
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student accuplacer Writing records Inserted ('||v_WRITINGCODE||')= '
          || v_writing_inscount);
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student records Not Inserted because accuplacer Writing soatest record exists ('||v_WRITINGCODE||') = '
          || v_writing_exists_count);
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student accuplacer Math records Inserted ('||v_MATHCODE||') = '
          || v_math_inscount);
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student records Not Inserted because accuplacer Math soatest record exists ('||v_MATHCODE||') = '
          || v_math_exists_count);
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
          'Number of Student records Processed = ' || v_stucount);
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
          'Number of Sortest records Inserted = ' || v_total_records_inscount);
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student records with Warnings - Record not Inserted = '
          || v_warcount);
     DBMS_OUTPUT.PUT_LINE (CHR (9) || '                   ');
     DBMS_OUTPUT.PUT_LINE (
             'Number of Student records with Errors - Record not Inserted = '
          || v_errcount);
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');
     DBMS_OUTPUT.PUT_LINE (
          '------------------------------------------------------------------------------');

     --
     --
     CLOSE temptab_accuplacer_cur;

     --
     --
     COMMIT;
--
END; --END BEGIN
/
spool off;
exit;