--  PROGRAM NAME:  accuplacer_truncate_temp.sql
--  VERSION:       1.0
--  DATE:          Feb 17, 2017 EmilySmartt
--  DESCRIPTION:   This script truncates the accuplacer dataload temp table
--                 pscccustom.accuplacer_temp.
--
--   06/2017  --   CHANGED TABLE NAME FOR CLEVELAND MOD.  
--                 TRUNCATE UC4 permissiion issues. Changed to DELETE.
--           
delete from BANINST1.CLSCC_ACCUPLACER_TEMP;
commit;
exit
