--  PROGRAM NAME:  accuplacer_calc_best_def.sql
--  VERSION:       1.0 
--  DATE:          3/28/2017 Emily Smartt
--  DESCRIPTION:   This script follows the loading of accuplacer test scores to Banner (accuplacer_insert_sortest.sql).
--                 It calls package procedures from SZKADEF (created by TBR) to calculate the best scores
--                 and deficiencies for the accuplacer scores that were just loaded into the
--                 pscccustom.accuplacer_temp table.
--                 Passing 'T1' as admt_in parameter to SZKADEF.p_process_best_tests will calculate best scores
--                 for all students (Dorothy Mayes 3/3/2011)
--                 
----  06/2017  -  Modified for Cleveland.   Accuplacer scores to load   BANINST1.CLSCC_ACCUPLACER_TEMP
--

spool &1;
set echo off;
set verify off;
set feedback off;
set heading on;
set pagesize 55;
set linesize 132;
set timing off;
set tab off;
set newpage 0;
set serveroutput on SIZE 1000000;
--TTITLE CENTER '     ACCUPLACER BEST SCORES AND DEFICIENTCIES INSERTED FOR ACCUPLACER DATALOAD REPORT - '||v_date'
--
--
--
--  Declare variables
--
--
DECLARE
   v_stucount       NUMBER(6) := 0;  
   v_date           DATE := sysdate; 
   v_disp_date      VARCHAR(25) := TO_CHAR(sysdate,'DD-MON-YYYY HH:MI:SS AM');
   v_pidm           NUMBER(8);
   V_id             VARCHAR2(10);  
   cutoff_date      DATE;
   term_start_date  DATE;
   admt_in          VARCHAR2(2) := 'T1'; 
   vid_exist                   VARCHAR2 (1);
--
--
   CURSOR            temptab_accuplacer_cur IS
   SELECT            distinct STUDENT_ID,FIRSTNAME,LASTNAME
   FROM              BANINST1.CLSCC_ACCUPLACER_TEMP
   WHERE  (SCORE1 IS NOT NULL
                  OR SCORE2 IS NOT NULL
                  OR SCORE3 IS NOT NULL);

   temptab_accuplacer_rec  temptab_accuplacer_cur%ROWTYPE;
   
     CURSOR check_spriden_id
     IS
          SELECT 'X'
            FROM spriden
           WHERE spriden_id = V_id AND spriden_change_ind IS NULL;   
--
--
--
--  Begin processing
--
BEGIN
   DBMS_OUTPUT.ENABLE(1000000);
   DBMS_OUTPUT.PUT_LINE(chr(9)||'     accuplacer BEST SCORES AND DEFICIENCIES PROCESSED FOR accuplacer RWM DATALOAD REPORT - '||v_disp_date);
   DBMS_OUTPUT.PUT_LINE(chr(9)|| '                   ');
   DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------');
   DBMS_OUTPUT.PUT_LINE(chr(9)|| '                   ');
--
   OPEN temptab_accuplacer_cur;
   LOOP
--
      FETCH temptab_accuplacer_cur INTO temptab_accuplacer_rec;
--
      IF temptab_accuplacer_cur%FOUND
      THEN
          V_id := temptab_accuplacer_rec.STUDENT_ID;
--             if substr(V_id,1,1) <> 'P' THEN
--                V_id := 'P' || V_id;
--               end if;
          
          
               OPEN check_spriden_id;
                FETCH check_spriden_id INTO vid_exist;

               --
               IF check_spriden_id%FOUND
               THEN
               
          
          SELECT spriden_pidm
          INTO   v_pidm
          FROM   spriden
          WHERE  spriden_id = V_id
          AND    spriden_change_ind is null;
--
--  get person's 3-year cutoff date for test calcs
-- 
          cutoff_date := NULL;
          term_start_date := NULL; 
          SZKADEF.p_get_cutoff_date(v_pidm, cutoff_date, term_start_date);
--
--  calculate best test and DSP test scores
--  Admit type will be used to denote "transfer" students.
--  Pass admit type into best test processing.
--
  
        admt_in := 'T1'; 

        SZKADEF.p_process_best_tests(v_pidm,
                                       cutoff_date,
                                       term_start_date,
                                       admt_in );


          SZKADEF.p_process_DSP_tests(v_pidm, cutoff_date);

--  add this per kim = does all		  
		  SZKADEF.p_process_ADEF_all(v_pidm);
--                               
          v_stucount := v_stucount + 1; 
--
          DBMS_OUTPUT.PUT_LINE( 'PROCESSING - ' ||  V_id || ' ' || INITCAP(temptab_accuplacer_rec.LASTNAME)
                                                || ', ' || INITCAP(temptab_accuplacer_rec.FIRSTNAME));
        END IF;
        CLOSE check_spriden_id;
--   
      END IF;
--
      EXIT WHEN temptab_accuplacer_cur%NOTFOUND;
--
      DBMS_OUTPUT.PUT_LINE(chr(9)|| '                   ');
--
   END LOOP;
-- 
--
   DBMS_OUTPUT.PUT_LINE(chr(9)|| '                   ');
   DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------');
   DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------');           
   DBMS_OUTPUT.PUT_LINE('Total Number of Student RWM accuplacer Best Score/Deficiency records Processed = '|| v_stucount);
   DBMS_OUTPUT.PUT_LINE(chr(9)|| '                   ');
   DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------');
   DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------');
   DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------------------------');
--    
--
CLOSE temptab_accuplacer_cur;
--
--
 COMMIT;
--
END;
/

SET SERVEROUTPUT OFF;
spool off;
exit;